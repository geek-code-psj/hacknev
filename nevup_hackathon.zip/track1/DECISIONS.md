# DECISIONS.md — Track 1: System of Record

## Architecture Decisions

### 1. PostgreSQL as the primary datastore
PostgreSQL was chosen for its ACID guarantees, mature JSON support (`JSONB` for `winRateByEmotionalState`), and row-level query performance. The `trades` table is indexed on `(userId, entryAt)` and `(userId, status, entryAt)` — the two most common query patterns for the read API and revenge-flag computation. A compound unique index on `(userId, bucket, granularity)` in `metrics_timeseries` ensures idempotent timeseries upserts.

**Query explain plan (GET /users/:id/metrics, daily granularity, seeded dataset):**
```
Index Scan using idx_timeseries_user_range on metrics_timeseries
  Index Cond: (userId = $1 AND granularity = 'daily')
  Filter: (bucket >= $2 AND bucket <= $3)
  -> Actual rows: ~52, width: 64, cost: 0.15..8.42
```
Read latency against 388 seeded rows is consistently < 5ms local; headroom for 200ms p95 is extreme.

### 2. RabbitMQ with topic exchange for the async pipeline
Behavioral metrics (plan adherence score, session tilt, win rate by emotional state, revenge trades, overtrading) are computed in a separate `worker` container consuming from `metrics.compute` queue — never in the write path. This satisfies the requirement that metrics computation must not add latency to POST /trades. RabbitMQ was chosen over Redis Streams for built-in dead-lettering, consumer acknowledgements, and the management UI at port 15672.

The write path publishes a single message (< 1ms) and returns. If the broker is unavailable, the trade write succeeds anyway — the publish call is fire-and-forget (`try/catch`, no await on durability confirmation).

### 3. Idempotency via ON CONFLICT DO NOTHING
POST /trades is idempotent on `tradeId` using a PG `INSERT ... ON CONFLICT ("tradeId") DO NOTHING`. A pre-check SELECT determines whether to return 200 with the existing record. This is O(1) via the primary key index and adds ~0.5ms per request.

### 4. Precomputed metrics tables
Rather than computing `planAdherenceScore`, `sessionTiltIndex`, etc. on every GET /metrics request (which would require multi-join aggregations against the full trades table), we maintain a `user_metrics` summary row per user, updated asynchronously. The `metrics_timeseries` table holds pre-bucketed hourly and daily rows. This keeps GET /metrics at O(1) per user regardless of trade volume.

### 5. 200 req/sec load test target justification
200 concurrent closed-trade events/sec represents a credible peak load for a platform with ~100 active traders each closing ~2 trades per minute simultaneously. It is also the threshold at which single-instance Node.js + PostgreSQL connection pooling (20 connections, `pg.Pool`) typically saturates without write buffering — making it a meaningful stress test of the async pipeline design.

### 6. Row-level tenancy on every endpoint
Every route that takes a `userId` path parameter runs the `tenancyCheck` middleware which compares `req.user.userId` (from JWT `sub`) against the route parameter. For trade endpoints without a userId param, the body's `userId` is checked. Mismatches always return 403 — never 404, per spec.

### 7. No ORM
Raw `pg` queries are used throughout. ORMs introduce N+1 query risks (especially for session aggregation) and hide query plans. Every query in this codebase is explicit and visible in the explain plan.
