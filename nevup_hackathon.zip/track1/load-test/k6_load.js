/**
 * k6 Load Test — NevUp Track 1
 * Target: 200 concurrent trade-close events/sec for 60s, p95 write latency <= 150ms
 *
 * Run: k6 run load-test/k6_load.js --out json=results.json
 * HTML report: k6 run load-test/k6_load.js --out web-dashboard
 */
import http from 'k6/http';
import { check, sleep } from 'k6';
import { Rate, Trend } from 'k6/metrics';
import { uuidv4 } from 'https://jslib.k6.io/k6-utils/1.4.0/index.js';

const BASE_URL = __ENV.BASE_URL || 'http://localhost:3000';

// Pre-minted test token (mint via jwt.io with secret 97791d...; replace for production runs)
const TOKEN = __ENV.TEST_TOKEN || 'REPLACE_WITH_MINTED_TOKEN';
const TEST_USER = __ENV.TEST_USER || 'f412f236-4edc-47a2-8f54-8763a6ed2ce8';

export const options = {
  scenarios: {
    trade_writes: {
      executor: 'constant-arrival-rate',
      rate: 200,          // 200 iterations/sec
      timeUnit: '1s',
      duration: '60s',
      preAllocatedVUs: 250,
      maxVUs: 500,
    },
  },
  thresholds: {
    'http_req_duration{name:post_trade}': ['p(95)<150'],  // p95 write latency
    'http_req_failed':                     ['rate<0.01'],  // <1% error rate
    'checks':                              ['rate>0.99'],
  },
};

const writeLatency = new Trend('write_latency_ms', true);
const errorRate    = new Rate('trade_errors');

export default function () {
  const tradeId   = uuidv4();
  const sessionId = uuidv4();
  const now       = new Date().toISOString();
  const exitAt    = new Date(Date.now() + 3600000).toISOString();

  const payload = JSON.stringify({
    tradeId,
    userId:         TEST_USER,
    sessionId,
    asset:          'AAPL',
    assetClass:     'equity',
    direction:      'long',
    entryPrice:     150.00,
    exitPrice:      155.00,
    quantity:       10,
    entryAt:        now,
    exitAt,
    status:         'closed',
    outcome:        'win',
    pnl:            50.00,
    planAdherence:  4,
    emotionalState: 'calm',
    entryRationale: 'k6 load test trade',
  });

  const res = http.post(`${BASE_URL}/trades`, payload, {
    headers: {
      'Content-Type':  'application/json',
      'Authorization': `Bearer ${TOKEN}`,
    },
    tags: { name: 'post_trade' },
  });

  writeLatency.add(res.timings.duration);
  errorRate.add(res.status >= 400 && res.status !== 409);

  const ok = check(res, {
    'status is 200':              r => r.status === 200,
    'has tradeId in body':        r => {
      try { return JSON.parse(r.body).tradeId === tradeId; } catch { return false; }
    },
  });

  if (!ok) {
    console.error(`FAIL ${res.status}: ${res.body.slice(0, 200)}`);
  }
}
