'use strict';
const fs   = require('fs');
const path = require('path');
const { parse } = require('csv-parse/sync');
const pool = require('./pool');

async function seed() {
  const csvPath = path.join(__dirname, '../../data/seed.csv');
  if (!fs.existsSync(csvPath)) {
    console.log(JSON.stringify({ event: 'seed_skip', reason: 'no seed file' }));
    return;
  }

  const raw = fs.readFileSync(csvPath, 'utf8');
  const rows = parse(raw, { columns: true, skip_empty_lines: true, cast: true });

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    let inserted = 0;
    let skipped  = 0;

    for (const r of rows) {
      const { rowCount } = await client.query(
        `INSERT INTO trades (
          "tradeId","userId","sessionId",asset,"assetClass",direction,
          "entryPrice","exitPrice",quantity,"entryAt","exitAt",status,
          outcome,pnl,"planAdherence","emotionalState","entryRationale","revengeFlag"
        ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18)
        ON CONFLICT ("tradeId") DO NOTHING`,
        [
          r.tradeId, r.userId, r.sessionId, r.asset, r.assetClass, r.direction,
          r.entryPrice,
          r.exitPrice === '' || r.exitPrice == null ? null : r.exitPrice,
          r.quantity,
          r.entryAt,
          r.exitAt === '' || r.exitAt == null ? null : r.exitAt,
          r.status,
          r.outcome === '' ? null : r.outcome,
          r.pnl === '' || r.pnl == null ? null : r.pnl,
          r.planAdherence === '' || r.planAdherence == null ? null : r.planAdherence,
          r.emotionalState === '' ? null : r.emotionalState,
          r.entryRationale === '' ? null : r.entryRationale,
          String(r.revengeFlag).toLowerCase() === 'true',
        ]
      );
      if (rowCount > 0) inserted++; else skipped++;
    }

    await client.query('COMMIT');
    console.log(JSON.stringify({ event: 'seed_complete', inserted, skipped, total: rows.length }));
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

module.exports = { seed };

if (require.main === module) {
  seed().then(() => process.exit(0)).catch(e => {
    console.error(e.message);
    process.exit(1);
  });
}
