'use strict';
require('dotenv').config();
const { connect, QUEUE_METRICS } = require('./broker');
const pool = require('../db/pool');

/**
 * Compute all 5 behavioral metrics for a user after a trade closes.
 * Runs outside the write path — consumes from RabbitMQ.
 */

async function computeMetrics(userId) {
  const client = await pool.connect();
  try {
    // 1. Plan Adherence Score — rolling 10-trade average
    const paRes = await client.query(
      `SELECT AVG("planAdherence") AS score
       FROM (
         SELECT "planAdherence" FROM trades
         WHERE "userId" = $1 AND status = 'closed' AND "planAdherence" IS NOT NULL
         ORDER BY "exitAt" DESC NULLS LAST LIMIT 10
       ) sub`,
      [userId]
    );
    const planAdherenceScore = paRes.rows[0]?.score ? parseFloat(paRes.rows[0].score) : null;

    // 2. Session Tilt Index — loss-following trades / total in current session
    // Get the user's most recent session
    const sessionRes = await client.query(
      `SELECT "sessionId"
       FROM trades WHERE "userId" = $1
       ORDER BY "entryAt" DESC LIMIT 1`,
      [userId]
    );
    let sessionTiltIndex = 0;
    if (sessionRes.rows.length > 0) {
      const { sessionId } = sessionRes.rows[0];
      const tiltRes = await client.query(
        `SELECT
           COUNT(*) FILTER (WHERE "revengeFlag" = true) AS loss_following,
           COUNT(*) AS total
         FROM trades
         WHERE "sessionId" = $1 AND "userId" = $2`,
        [sessionId, userId]
      );
      const { loss_following, total } = tiltRes.rows[0];
      sessionTiltIndex = total > 0 ? parseFloat(loss_following) / parseFloat(total) : 0;
    }

    // 3. Win Rate by Emotional State
    const wrRes = await client.query(
      `SELECT "emotionalState",
              COUNT(*) FILTER (WHERE outcome = 'win') AS wins,
              COUNT(*) FILTER (WHERE outcome = 'loss') AS losses
       FROM trades
       WHERE "userId" = $1 AND status = 'closed' AND "emotionalState" IS NOT NULL
       GROUP BY "emotionalState"`,
      [userId]
    );
    const winRateByEmotionalState = {};
    for (const row of wrRes.rows) {
      const wins   = parseInt(row.wins);
      const losses = parseInt(row.losses);
      const total  = wins + losses;
      winRateByEmotionalState[row.emotionalState] = {
        wins, losses, winRate: total > 0 ? wins / total : 0
      };
    }

    // 4. Revenge Trade Count
    const rtRes = await client.query(
      `SELECT COUNT(*) AS cnt FROM trades WHERE "userId" = $1 AND "revengeFlag" = true`,
      [userId]
    );
    const revengeTrades = parseInt(rtRes.rows[0].cnt);

    // 5. Overtrading Events Count
    const otRes = await client.query(
      `SELECT COUNT(*) AS cnt FROM overtrading_events WHERE "userId" = $1`,
      [userId]
    );
    const overtradingEvents = parseInt(otRes.rows[0].cnt);

    // Upsert user_metrics
    await client.query(
      `INSERT INTO user_metrics (
         "userId","planAdherenceScore","sessionTiltIndex",
         "winRateByEmotionalState","revengeTrades","overtradingEvents","updatedAt"
       ) VALUES ($1,$2,$3,$4,$5,$6,NOW())
       ON CONFLICT ("userId") DO UPDATE SET
         "planAdherenceScore"     = EXCLUDED."planAdherenceScore",
         "sessionTiltIndex"       = EXCLUDED."sessionTiltIndex",
         "winRateByEmotionalState"= EXCLUDED."winRateByEmotionalState",
         "revengeTrades"          = EXCLUDED."revengeTrades",
         "overtradingEvents"      = EXCLUDED."overtradingEvents",
         "updatedAt"              = NOW()`,
      [userId, planAdherenceScore, sessionTiltIndex,
       JSON.stringify(winRateByEmotionalState), revengeTrades, overtradingEvents]
    );

    // Update timeseries buckets (hourly & daily)
    await updateTimeseries(client, userId);

  } finally {
    client.release();
  }
}

async function updateTimeseries(client, userId) {
  // Daily buckets
  await client.query(
    `INSERT INTO metrics_timeseries ("userId", bucket, granularity, "tradeCount", "winRate", pnl, "avgPlanAdherence", "updatedAt")
     SELECT
       "userId",
       DATE_TRUNC('day', "exitAt") AS bucket,
       'daily',
       COUNT(*),
       COUNT(*) FILTER (WHERE outcome='win')::float / NULLIF(COUNT(*),0),
       SUM(pnl),
       AVG("planAdherence"),
       NOW()
     FROM trades
     WHERE "userId" = $1 AND status = 'closed' AND "exitAt" IS NOT NULL
     GROUP BY "userId", DATE_TRUNC('day', "exitAt")
     ON CONFLICT ("userId", bucket, granularity) DO UPDATE SET
       "tradeCount"       = EXCLUDED."tradeCount",
       "winRate"          = EXCLUDED."winRate",
       pnl                = EXCLUDED.pnl,
       "avgPlanAdherence" = EXCLUDED."avgPlanAdherence",
       "updatedAt"        = NOW()`,
    [userId]
  );

  // Hourly buckets
  await client.query(
    `INSERT INTO metrics_timeseries ("userId", bucket, granularity, "tradeCount", "winRate", pnl, "avgPlanAdherence", "updatedAt")
     SELECT
       "userId",
       DATE_TRUNC('hour', "exitAt") AS bucket,
       'hourly',
       COUNT(*),
       COUNT(*) FILTER (WHERE outcome='win')::float / NULLIF(COUNT(*),0),
       SUM(pnl),
       AVG("planAdherence"),
       NOW()
     FROM trades
     WHERE "userId" = $1 AND status = 'closed' AND "exitAt" IS NOT NULL
     GROUP BY "userId", DATE_TRUNC('hour', "exitAt")
     ON CONFLICT ("userId", bucket, granularity) DO UPDATE SET
       "tradeCount"       = EXCLUDED."tradeCount",
       "winRate"          = EXCLUDED."winRate",
       pnl                = EXCLUDED.pnl,
       "avgPlanAdherence" = EXCLUDED."avgPlanAdherence",
       "updatedAt"        = NOW()`,
    [userId]
  );
}

/**
 * Check overtrading: >10 trades in any 30-min sliding window
 */
async function checkOvertrading(userId) {
  const client = await pool.connect();
  try {
    const res = await client.query(
      `SELECT "entryAt" FROM trades
       WHERE "userId" = $1 AND "entryAt" > NOW() - INTERVAL '1 hour'
       ORDER BY "entryAt"`,
      [userId]
    );
    const times = res.rows.map(r => new Date(r.entryAt).getTime());
    for (let i = 0; i < times.length; i++) {
      const windowEnd = times[i] + 30 * 60 * 1000;
      const count = times.filter(t => t >= times[i] && t <= windowEnd).length;
      if (count > 10) {
        await client.query(
          `INSERT INTO overtrading_events ("userId", window_start, window_end, trade_count)
           VALUES ($1, $2, $3, $4)`,
          [userId, new Date(times[i]).toISOString(), new Date(windowEnd).toISOString(), count]
        );
        console.log(JSON.stringify({ event: 'overtrading_detected', userId, count }));
        break;
      }
    }
  } finally {
    client.release();
  }
}

async function main() {
  const broker = await connect();
  const { QUEUE_METRICS } = require('./broker');

  broker.prefetch(10);

  broker.consume(QUEUE_METRICS, async (msg) => {
    if (!msg) return;
    try {
      const payload = JSON.parse(msg.content.toString());
      const { userId } = payload;
      await computeMetrics(userId);
      if (payload.eventType === 'trade.opened') {
        await checkOvertrading(userId);
      }
      broker.ack(msg);
      console.log(JSON.stringify({ event: 'metrics_computed', userId }));
    } catch (err) {
      console.error(JSON.stringify({ event: 'worker_error', error: err.message }));
      broker.nack(msg, false, false); // dead-letter, don't requeue
    }
  }, { noAck: false });

  console.log(JSON.stringify({ event: 'worker_started', queue: QUEUE_METRICS }));
}

main().catch(err => {
  console.error(JSON.stringify({ event: 'worker_fatal', error: err.message }));
  process.exit(1);
});
