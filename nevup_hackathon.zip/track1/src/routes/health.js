'use strict';
const express = require('express');
const pool    = require('../db/pool');
const broker  = require('../queue/broker');

const router = express.Router();

router.get('/', async (req, res) => {
  let dbConnection = 'disconnected';
  let queueLag     = -1;

  try {
    await pool.query('SELECT 1');
    dbConnection = 'connected';
  } catch {}

  try {
    const ch = broker.getChannel();
    queueLag = ch ? 0 : -1;
  } catch {}

  const status = dbConnection === 'connected' ? 'ok' : 'degraded';

  return res.status(status === 'ok' ? 200 : 503).json({
    status,
    dbConnection,
    queueLag,
    timestamp: new Date().toISOString(),
  });
});

module.exports = router;
